Steps to reproduce solution
1. Upload TEAM_a__MAIZE__ing_XGBOOST_solution notebook to colab,
   run all to get the CGIAR_XGBOOST submission file

2. Upload TEAM_a__MAIZE__ing_LGBM_solution notebook to colab,
   run all to get the CGIAR_LGBM submission file

3. Upload TEAM_a__MAIZE__ing_blending to colab,
   upload the CGIAR_XGBOOST file
   upload the CGIAR_LGBM file
   run all to get the Final_Submission file

4. Upload the generated Final_Submission file to Zindi to reproduce result

Thank You!		